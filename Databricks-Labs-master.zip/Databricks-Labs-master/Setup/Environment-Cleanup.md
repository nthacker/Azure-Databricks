# Environment Cleanup

This article describes the steps required to cleanup your Azure subscription and avoid unnecessary costs. Perform these only if you are finished with the labs.

1. Login to the Azure Portal.
2. Navigate to the resource group you deployed.
3. Select Delete resource group.
4. Type the name of the resource group and select Delete.
5. In a few minutes, all of the resources you used in these labs will be deleted.